require './decoder'

puts decode([1, 3, 5])
puts decode([1, 18, 3, 1, 4, 5])
